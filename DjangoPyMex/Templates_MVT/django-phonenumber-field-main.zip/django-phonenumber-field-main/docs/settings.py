DATABASES = {}
SECRET_KEY = "secretkey"
INSTALLED_APPS = ["phonenumber_field"]
